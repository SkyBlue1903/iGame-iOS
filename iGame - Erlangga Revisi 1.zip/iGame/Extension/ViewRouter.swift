//
//  ViewRouter.swift
//  iGame
//
//  Created by Erlangga Anugrah Arifin on 22/10/22.
//

import SwiftUI

class ViewRouter: ObservableObject {

  @Published var currentPage: Page = .welcome

}
