//
//  Page.swift
//  iGame
//
//  Created by Erlangga Anugrah Arifin on 22/10/22.
//

import Foundation

enum Page {
  case welcome
  case home
}
